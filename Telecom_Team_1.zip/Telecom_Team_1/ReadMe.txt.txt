The project is based on Java Spring Boot + ReactJs

Prerequisites : you should have JDK17+ ,Java IDE of your choice and NodeJS 18.0+ Installed

To start the project:-
 1- cd telecom-fe 
 2- npm install 
 3- npm start
 4- Open telecom in your favorite IDE and start TelecomApplication
 5- head to localhost:3000 and you will get access to the fe
