package com.telecom.telecom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TelecomApplicationTests {

	@Test
	void contextLoads() {
	}

}
