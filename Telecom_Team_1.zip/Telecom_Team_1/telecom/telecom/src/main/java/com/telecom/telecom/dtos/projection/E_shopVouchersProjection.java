package com.telecom.telecom.dtos.projection;

public interface E_shopVouchersProjection {
    Integer getShopID();
    String getURL();
    Integer getRating();
    Integer getVoucherID();
    Integer getValue();

}
