package com.telecom.telecom.dtos.projection;

public interface AccountPlanOnDateProjection {
    String getMobileNo();
    Integer getPlanId();
    String getName();

}
