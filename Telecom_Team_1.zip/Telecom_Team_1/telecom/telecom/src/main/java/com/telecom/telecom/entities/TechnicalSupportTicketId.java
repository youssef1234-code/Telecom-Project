package com.telecom.telecom.entities;

import jakarta.persistence.Embeddable;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Embeddable
public class TechnicalSupportTicketId implements java.io.Serializable {
    private static final long serialVersionUID = 1776772955902422339L;
}