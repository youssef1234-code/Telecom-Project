package com.telecom.telecom.dtos.projection;

public interface AllShopsProjection {
    Integer getShopID();
    String getName();
    String getCategory();
}
