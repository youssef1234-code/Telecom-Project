package com.telecom.telecom.dtos.projection;


public interface ConsumptionProjection {
    Integer getDataConsumption();
    Integer getMinutesUsed();
    Integer getSms();


}
