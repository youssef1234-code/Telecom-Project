package com.telecom.telecom.entities;

import jakarta.persistence.Embeddable;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Embeddable
public class SubscriptionId implements java.io.Serializable {
    private static final long serialVersionUID = 3858121056938032214L;
}