package com.telecom.telecom.dtos.projection;

public interface NumOfCashbackProjection {
    Integer getTrxCount();
    Integer getWalletID();
}
