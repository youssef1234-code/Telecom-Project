package com.telecom.telecom.dtos.projection;

public interface ExclusiveOfferProjection {
    Integer getOfferID();
    Integer getBenefitID();
    Integer getInternetOffered();
    Integer getSmsOffered();
    Integer getMinutesOffered();
}